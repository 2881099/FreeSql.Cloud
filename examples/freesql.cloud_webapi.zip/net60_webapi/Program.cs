using FreeSql;
using net60_webapi;
using Rougamo.Context;
using System.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton(DB.Cloud); //ע�� FreeSqlCloud<DbEnum>
builder.Services.AddSingleton(provider => DB.Cloud.Use(DbEnum.db1)); //ע�� db1 IFreeSql
builder.Services.AddScoped<UnitOfWorkManagerCloud>();

//����ע�� Repository
builder.Services.AddScoped(typeof(IBaseRepository<>), typeof(RepositoryCloud<>)); //db1
builder.Services.AddScoped(typeof(BaseRepository<>), typeof(RepositoryCloud<>)); //db1
builder.Services.AddScoped(typeof(IBaseRepository<,>), typeof(RepositoryCloud<,>)); //db1
builder.Services.AddScoped(typeof(BaseRepository<,>), typeof(RepositoryCloud<,>)); //db1
foreach (var repositoryType in typeof(User).Assembly.GetTypes().Where(a => a.IsAbstract == false && typeof(IBaseRepository).IsAssignableFrom(a)))
    builder.Services.AddScoped(repositoryType);

builder.Services.AddScoped<UserService>();

var app = builder.Build();

app.Use(async (context, next) =>
{
    TransactionalAttribute.SetServiceProvider(context.RequestServices);
    await next();
});

app.MapGet("/", async context =>
{
    var _userService = context.RequestServices.GetService<UserService>();
    _userService.Test01();

    await context.Response.WriteAsync("hello word");
});

app.Run();

class UserService
{
    readonly IBaseRepository<User> m_repo1;
    readonly BaseRepository<User> m_repo2;
    readonly UserRepository m_repo3;
    public UserService(IBaseRepository<User> repo1, BaseRepository<User> repo2, UserRepository repo3)
    {
        m_repo1 = repo1;
        m_repo2 = repo2;
        m_repo3 = repo3;
    }


    [Transactional] //db1
    [TransactionalDb2]
    public void Test01()
    {
        Console.WriteLine("xxx");
    }
}

class UserRepository : RepositoryCloud<User>, IBaseRepository<User>
{
    public UserRepository(UnitOfWorkManagerCloud uowm) : base(DbEnum.db2, uowm) { }

    //todo..
}

class UnitOfWorkManagerCloud
{
    readonly Dictionary<DbEnum, UnitOfWorkManager> m_managers = new Dictionary<DbEnum, UnitOfWorkManager>();
    readonly FreeSqlCloud<DbEnum> m_cloud;
    public UnitOfWorkManagerCloud(IServiceProvider serviceProvider)
    {
        m_cloud = serviceProvider.GetService<FreeSqlCloud<DbEnum>>();
    }

    public void Dispose()
    {
        foreach(var uowm in m_managers.Values)
        {
            uowm.Dispose();
        }
        m_managers.Clear();
    }
    public IUnitOfWork Begin(DbEnum db, Propagation propagation = Propagation.Required, IsolationLevel? isolationLevel = null)
    {
        return GetUnitOfWorkManager(db).Begin(propagation, isolationLevel);
    }
    public UnitOfWorkManager GetUnitOfWorkManager(DbEnum db)
    {
        if (m_managers.TryGetValue(db, out var uowm) == false)
        {
            uowm = new UnitOfWorkManager(m_cloud.Use(db));
            m_managers.Add(db, uowm);
        }
        return uowm;
    }
}

class RepositoryCloud<T> : DefaultRepository<T, int> where T : class
{
    public RepositoryCloud(UnitOfWorkManagerCloud uomw) : this(DbEnum.db1, uomw) { } //DI
    public RepositoryCloud(DbEnum db, UnitOfWorkManagerCloud uomw) : this(uomw.GetUnitOfWorkManager(db)) { }
    RepositoryCloud(UnitOfWorkManager uomw) : base(uomw.Orm, uomw)
    {
        uomw.Binding(this);
    }
    
}
class RepositoryCloud<T, TKey> : DefaultRepository<T, TKey> where T : class
{
    public RepositoryCloud(UnitOfWorkManagerCloud uomw) : this(DbEnum.db1, uomw) { } //DI
    public RepositoryCloud(DbEnum db, UnitOfWorkManagerCloud uomw) : this(uomw.GetUnitOfWorkManager(db)) { }
    RepositoryCloud(UnitOfWorkManager uomw) : base(uomw.Orm, uomw)
    {
        uomw.Binding(this);
    }
}


[AttributeUsage(AttributeTargets.Method)]
public class TransactionalDb2Attribute : TransactionalAttribute
{
    public TransactionalDb2Attribute() : base(DbEnum.db2) { }
}
[AttributeUsage(AttributeTargets.Method)]
public class TransactionalDb3Attribute : TransactionalAttribute
{
    public TransactionalDb3Attribute() : base(DbEnum.db3) { }
}
[AttributeUsage(AttributeTargets.Method)]
public class TransactionalAttribute : Rougamo.MoAttribute
{
    public Propagation Propagation { get; set; } = Propagation.Required;
    public IsolationLevel IsolationLevel { get => m_IsolationLevel.Value; set => m_IsolationLevel = value; }
    IsolationLevel? m_IsolationLevel;
    readonly DbEnum m_db;

    public TransactionalAttribute() { }
    protected TransactionalAttribute(DbEnum db)
    {
        m_db = db;
    }

    static AsyncLocal<IServiceProvider> m_ServiceProvider = new AsyncLocal<IServiceProvider>();
    public static void SetServiceProvider(IServiceProvider serviceProvider) => m_ServiceProvider.Value = serviceProvider;

    IUnitOfWork _uow;
    public override void OnEntry(MethodContext context)
    {
        var uowManager = m_ServiceProvider.Value.GetService<UnitOfWorkManagerCloud>();
        _uow = uowManager.Begin(m_db, this.Propagation, this.m_IsolationLevel);
    }
    public override void OnExit(MethodContext context)
    {
        if (typeof(Task).IsAssignableFrom(context.RealReturnType))
            ((Task)context.ReturnValue).ContinueWith(t => _OnExit());
        else _OnExit();

        void _OnExit()
        {
            try
            {
                if (context.Exception == null) _uow.Commit();
                else _uow.Rollback();
            }
            finally
            {
                _uow.Dispose();
            }
        }
    }
}