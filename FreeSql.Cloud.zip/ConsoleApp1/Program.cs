﻿using FreeSql;
using FreeSql.Cloud;
using System;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        async static Task Main(string[] args)
        {
            using (var fsqlc = new FreeSqlCloud())
            {
                fsqlc.Register("db1", () => new FreeSqlBuilder().UseConnectionString(FreeSql.DataType.Sqlite, @"Data Source=db1.db").Build());
                fsqlc.Register("db2", () => new FreeSqlBuilder().UseConnectionString(FreeSql.DataType.Sqlite, @"Data Source=db2.db").Build());
                fsqlc.Register("db3", () => new FreeSqlBuilder().UseConnectionString(FreeSql.DataType.Sqlite, @"Data Source=db3.db").Build());

                var tid = Guid.NewGuid().ToString();
                await fsqlc.TccAsync(tid, new Tcc1(), new Tcc2(), new Tcc3());
            }
        }
    }

    [TccCloud("db1")]
    class Tcc1 : ITryConfimCancel
    {
        public Task Cancel(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Confirm(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Try(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
    }

    [TccCloud("db2")]
    class Tcc2 : ITryConfimCancel
    {
        public Task Cancel(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Confirm(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Try(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
    }

    [TccCloud("db3")]
    class Tcc3 : ITryConfimCancel
    {
        public Task Cancel(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Confirm(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Try(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
    }
}
