﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace FreeSql.Cloud
{
    class Test
    {
        async Task Tcc()
        {
            var fsqlc = new FreeSqlCloud();
            fsqlc.Register("db1", () => new FreeSqlBuilder().Build());
            fsqlc.Register("db2", () => new FreeSqlBuilder().Build());
            fsqlc.Register("db3", () => new FreeSqlBuilder().Build());

            var tid = Guid.NewGuid().ToString();
            await fsqlc.TccAsync(tid, new Tcc1(), new Tcc2(), new Tcc3());

            //await fsqlc.TccConfimCancelAsync(tid);
        }
    }

    [TccCloud("db1")]
    class Tcc1 : ITryConfimCancel
    {
        public Task Cancel(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Confirm(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Try(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
    }

    [TccCloud("db2")]
    class Tcc2 : ITryConfimCancel
    {
        public Task Cancel(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Confirm(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Try(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
    }

    [TccCloud("db3")]
    class Tcc3 : ITryConfimCancel
    {
        public Task Cancel(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Confirm(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
        public Task Try(IFreeSql fsql)
        {
            return Task.CompletedTask;
        }
    }
}
