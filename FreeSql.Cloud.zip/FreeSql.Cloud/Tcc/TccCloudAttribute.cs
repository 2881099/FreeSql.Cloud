﻿using FreeSql.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace FreeSql.Cloud
{
    
    [AttributeUsage(AttributeTargets.Class)]
    public class TccCloudAttribute : Attribute
    {
        public string Name { get; set; }
        public IsolationLevel IsolationLevel { get => _IsolationLevelPriv.Value; set => _IsolationLevelPriv = value; }
        internal IsolationLevel? _IsolationLevelPriv;
        public TccCloudAttribute(string name)
        {
            this.Name = name;
        }
    }
}
