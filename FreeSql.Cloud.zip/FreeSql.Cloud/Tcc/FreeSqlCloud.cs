﻿using FreeSql.DataAnnotations;
using FreeSql.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace FreeSql.Cloud
{
    partial class FreeSqlCloud
    {
        async public Task TccAsync(string tid, params ITryConfimCancel[] tccs)
        {
            if (string.IsNullOrEmpty(_masterName)) throw new ArgumentException($"必须注册可用的服务");
            tccs = tccs?.Where(a => a != null).ToArray();
            if (tccs?.Any() != true) throw new ArgumentNullException(nameof(tccs));
            var tccTypeNames = tccs.Select(a => a.GetType().AssemblyQualifiedName).ToArray();
            foreach(var tccTypeName in tccTypeNames)
            {
                try
                {
                    var tccType = Type.GetType(tccTypeName);
                    var tccTypeDefault = tccType.CreateInstanceGetDefaultValue();
                    if (tccTypeDefault == null) throw new ArgumentException($"{tccTypeName} 无法创建 ITryConfirmCancel");
                }
                catch
                {
                    throw new ArgumentException($"{tccTypeName} 无法创建 ITryConfirmCancel");
                }
            }

            var tccAttrs = tccs.Select(a => a.GetType().GetCustomAttribute<TccCloudAttribute>()).Where(a => a != null).ToArray();
            var tccOrms = tccAttrs.Select(a => _ib.Get(a.Name)).ToArray();
            if (tccOrms.Length != tccs.Length) throw new ArgumentException($"ITryConfirmCancel 必须指定特性 FreeSqlCloudAttribute");

            var tccMaster = new TccMaster
            {
                Tid = tid,
                Total = tccs.Length,
                TypeNames = string.Join("\r\n", tccTypeNames),
                Status = TccMasterStatus.Pending,
                RetryCount = 0
            };
            await _master.Insert(tccMaster).ExecuteAffrowsAsync();
            var tccTasks = new List<TccTask>();

            Exception tccTryException = null;
            var tccTryIndex = 0;
            for (var idx = 0; idx < tccs.Length; idx++)
            {
                try
                {
                    using (var uow = tccOrms[idx].CreateUnitOfWork())
                    {
                        uow.IsolationLevel = tccAttrs[idx]._IsolationLevelPriv;
                        var fsql = TccOrm.Create(tccOrms[idx], () => uow.GetOrBeginTransaction());

                        tccTasks.Add(new TccTask
                        {
                            Tid = tid,
                            Index = idx,
                            Stage = TccTaskStage.Try,
                            TypeName = tccTypeNames[idx],
                        });
                        await fsql.Insert(tccTasks[idx]).ExecuteAffrowsAsync();
                        await tccs[idx].Try(fsql);
                        uow.Commit();
                    }
                }
                catch (Exception ex)
                {
                    tccTryException = ex.InnerException?.InnerException ?? ex.InnerException ?? ex;
                    break;
                }
                tccTryIndex++;
            }
            await TccConfimCancelAsync(tccMaster, tccTasks, tccs, tccOrms, tccAttrs, true);
        }
        public Task TccConfimCancelAsync(string tid) => TccConfimCancelAsync(tid, false);
        async Task TccConfimCancelAsync(string tid, bool retry)
        {
            var tccMaster = await _master.Select<TccMaster>().Where(a => a.Tid == tid && a.Status == TccMasterStatus.Pending && a.RetryCount <= 30).FirstAsync();
            if (tccMaster == null) return;
            var tccs = tccMaster.TypeNames.Split(new string[] { "\r\n" }, StringSplitOptions.None)
                .Where(tccTypeName => string.IsNullOrWhiteSpace(tccTypeName) == false)
                .Select(tccTypeName =>
                {
                    try
                    {
                        var tccType = Type.GetType(tccTypeName);
                        var tccTypeDefault = tccType.CreateInstanceGetDefaultValue() as ITryConfimCancel;
                        if (tccTypeDefault == null) throw new ArgumentException($"{tccTypeName} 无法创建 ITryConfirmCancel");
                        return tccTypeDefault;
                    }
                    catch
                    {
                        throw new ArgumentException($"{tccTypeName} 无法创建 ITryConfirmCancel");
                    }
                })
                .ToArray();
            if (tccs?.Any() != true) throw new Exception($"tid = {tid} 数据有误");
            var tccAttrs = tccs.Select(a => a.GetType().GetCustomAttribute<TccCloudAttribute>()).Where(a => a != null).ToArray();
            var tccOrms = tccAttrs.Select(a => _ib.Get(a.Name)).ToArray();
            if (tccOrms.Length != tccs.Length) throw new ArgumentException($"ITryConfirmCancel 必须指定特性 FreeSqlCloudAttribute");

            var tccTasks = tccOrms.SelectMany(z => z.Select<TccTask>().Where(a => a.Tid == tid).ToList()).ToList();
            await TccConfimCancelAsync(tccMaster, tccTasks, tccs.ToArray(), tccOrms, tccAttrs, retry);
        }
        async Task TccConfimCancelAsync(TccMaster tccMaster, List<TccTask> tccTasks, ITryConfimCancel[] tccs, IFreeSql[] tccOrms, TccCloudAttribute[] tccAttrs, bool retry)
        {
            var isConfirm = tccTasks.Count == tccMaster.Total;
            var successCount = 0;
            for (var idx = tccs.Length - 1; idx >= 0; idx--)
            {
                try
                {
                    if (tccTasks.Where(tt => tt.Index == idx && tt.Stage == TccTaskStage.Try).Any())
                    {
                        using (var uow = tccOrms[idx].CreateUnitOfWork())
                        {
                            uow.IsolationLevel = tccAttrs[idx]._IsolationLevelPriv;
                            var fsql = TccOrm.Create(tccOrms[idx], () => uow.GetOrBeginTransaction());
                            var affrows = await fsql.Update<TccTask>()
                                .Where(a => a.Tid == tccMaster.Tid && a.Index == idx && a.Stage == TccTaskStage.Try)
                                .Set(a => a.Stage, isConfirm ? TccTaskStage.Confirm : TccTaskStage.Cancel)
                                .ExecuteAffrowsAsync();
                            if (affrows == 1)
                            {
                                if (isConfirm) await tccs[idx].Confirm(fsql);
                                else await tccs[idx].Cancel(fsql);
                            }
                            uow.Commit();
                        }
                    }
                    successCount++;
                }
                catch
                {
                }
            }
            if (successCount == tccs.Length)
                await _master.Update<TccMaster>()
                    .Where(a => a.Tid == tccMaster.Tid && a.Status == TccMasterStatus.Pending)
                    .Set(a => a.Status, isConfirm ? TccMasterStatus.Confirmed : TccMasterStatus.Canceled)
                    .ExecuteAffrowsAsync();
            else
            {
                var affrows = await _master.Update<TccMaster>()
                    .Where(a => a.Tid == tccMaster.Tid && a.Status == TccMasterStatus.Pending)
                    .Set(a => a.RetryCount + 1)
                    .ExecuteAffrowsAsync();
                if (retry && affrows == 1)
                {
                    //lazy exec
                    _scheduer.AddTempTask(TimeSpan.FromSeconds(60), GetTempTask(tccMaster.Tid));
                }
            }
        }
        Action GetTempTask(string tid)
        {
            return () =>
            {
                try
                {
                    TccConfimCancelAsync(tid, true).Wait();
                }
                catch
                {
                    try
                    {
                        _master.Update<TccMaster>()
                           .Where(a => a.Tid == tid && a.Status == TccMasterStatus.Pending)
                           .Set(a => a.RetryCount + 1)
                           .ExecuteAffrows();
                    }
                    catch { }
                    _scheduer.AddTempTask(TimeSpan.FromSeconds(60), GetTempTask(tid));
                }
            };
        }
    }
}
