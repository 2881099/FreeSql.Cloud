﻿using FreeSql.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Text;

namespace FreeSql.Cloud
{
    [Table(Name = "tcc_master")]
    public class TccMaster
    {
        [Column(Name = "tid", IsPrimary = true, StringLength = 128)]
        public string Tid { get; set; }

        [Column(Name = "total")]
        public int Total { get; set; }

        [Column(Name = "type_names", StringLength = -1)]
        public string TypeNames { get; set; }

        [Column(Name = "create_time", ServerTime = DateTimeKind.Utc)]
        public DateTime CreateTime { get; set; } = DateTime.UtcNow;

        [Column(Name = "status", MapType = typeof(string), StringLength = 10)]
        public TccMasterStatus Status { get; set; }

        [Column(Name = "retry_count")]
        public int RetryCount { get; set; }
    }
    public enum TccMasterStatus { Pending, Confirmed, Canceled }


    [Table(Name = "tcc_task")]
    public class TccTask
    {
        [Column(Name = "tid", IsPrimary = true, StringLength = 128)]
        public string Tid { get; set; }

        [Column(Name = "index", IsPrimary = true)]
        public int Index { get; set; }

        [Column(Name = "stage", MapType = typeof(string), StringLength = 8)]
        public TccTaskStage Stage { get; set; }

        [Column(Name = "type_name")]
        public string TypeName { get; set; }
    }
    public enum TccTaskStage { Try, Confirm, Cancel }
}
