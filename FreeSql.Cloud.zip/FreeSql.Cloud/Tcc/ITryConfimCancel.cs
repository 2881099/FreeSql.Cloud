﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace FreeSql.Cloud
{
    public interface ITryConfimCancel
    {
        Task Try(IFreeSql fsql);
        Task Confirm(IFreeSql fsql);
        Task Cancel(IFreeSql fsql);
    }
}
